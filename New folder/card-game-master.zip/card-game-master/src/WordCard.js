import React, { Component } from 'react';
import CharacterCard from "./CharacterCard";
import _ from 'lodash';

const prepareSrareFromWord = (given_word) => {
    let word = given_word.toUpperCase()
    let chars = _.shuffle(Array.from(word))
    return{
        word,
        char,
        attemp:1,
        guess: [],
        comlete: false
    }
}
export default class WordCard extends Component{
    activationHandler = c => {
        let guess = [...this.state.guess,c]
        this.setState({guess})
        if(guess.length == this.state.chars.length){
            if(guess.join('').toString() == this.state.word){
                this.setState({guess: [],comleted:true})
            }else{
                this.setState({guess:[],attemp:this.state.attemp + 1})
            }
        }
    }
    render(){
        return(
            <div>
                { Array.from(this.props.value).map((c, i) => <CharacterCard value={c} key={i} activationHandler={this.activationHandler}/>) }
            </div>
        )
    }
}